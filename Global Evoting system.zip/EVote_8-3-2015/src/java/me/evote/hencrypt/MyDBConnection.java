package me.evote.hencrypt;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Devavrat
 */
public class MyDBConnection {
    public static String msg="";
      
    
     public static Connection getCon()
    { Connection con=null;
        try {
           
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/evote","root","root");
            System.out.println("Connection Done");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
            Logger.getLogger(MyDBConnection.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MyDBConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
       public static boolean getVerify(String s)
    { 
        try {
           Connection con=getCon();
            Statement ss=con.createStatement();
            ResultSet rs=ss.executeQuery(s);
            if(rs.next())
            {
                 System.out.println("Login successfull");
                return true;
            }
           
        } catch (SQLException ex) {
            Logger.getLogger(MyDBConnection.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
     public static boolean fireQuery(String q)
   {
       try {
           Connection c=getCon();
           Statement smnt=c.createStatement();
                   int i=smnt.executeUpdate(q);
                   System.out.println(q);
           if(i>0)
           {
                 System.out.println("query successfull");
                return true;
           }
           
          
       } catch (SQLException ex) {
           Logger.getLogger(MyDBConnection.class.getName()).log(Level.SEVERE, null, ex);
       }
        return false;
   }
}
