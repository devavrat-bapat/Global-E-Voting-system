/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt;
import java.sql.*;
/**
 *
 * @author Devavrat
 */
public class CalculateVoteThread implements Runnable{
Thread t;
    public CalculateVoteThread() {
        t=new Thread(this);
        t.start();
    }

    @Override
    public void run() {
         int count=1;
        while(true){
            
        try {
                 Connection c=MyDBConnection.getCon();
       /*if(count==1)
       {
           c.createStatement().executeUpdate("delete from postresult,creategraph,votepercentage");
           count++;
               
       }*/
           Statement s=c.createStatement();
            ResultSet rs=s.executeQuery("SELECT * FROM votedtls WHERE TIMESTAMPDIFF(MINUTE,CONCAT(RSDATE, ' ', RSTIME),NOW())>=0");
            int i=0;
            String id="";
            while(rs.next())
            {
                String p,cid;
                p=rs.getString("post");
                cid=rs.getString("cid");
                String noofvoters="";
                String noofvotes="";
                String canname="",canid="";
                String pid="";
                //total no of voters
                ResultSet rs1=c.createStatement().executeQuery("select count(vid) from voterdetails where cid='"+cid+"'");
                if(rs1.next())
                {
                    noofvoters=rs1.getString(1);
                }
                 rs1.close();
                //get post id
               ResultSet rs4=c.createStatement().executeQuery("select pid from cpost where cid='"+cid+"' and post='"+p+"'");
               if(rs4.next())
               {
                   pid=rs4.getString(1);
               }
                rs4.close();
               //fetch each candidate
                ResultSet rs2=c.createStatement().executeQuery("select name,uname from candidatedetails where cid='"+cid+"' and forpost='"+p+"' and allowed='Yes'");
                 while(rs2.next())
                {
                canname=rs2.getString(1);
                canid=rs2.getString(2);
                //fetch voters for each candidate
                ResultSet rs3=c.createStatement().executeQuery("select count(fvid) from fvotedtls where client='"+cid+"' and post='"+p+"' and canid='"+canid+"'");
                 if(rs3.next())
                {
                    noofvotes=rs3.getString(1);
                         if(!(c.createStatement().executeQuery("select * from postresult where result='"+cid+"' and pid="+pid).next()))
                         {
                   c.createStatement().executeUpdate("insert into votepercentage(canname,noofvotes,cid,post,noofvoters,canid) "
                            + "values('"+canname+"','"+noofvotes+"','"+cid+"','"+p+"','"+noofvoters+"','"+canid+"')");
                
                   
                          
                      
                   
                         }
                
                }
                 rs3.close();
                 
                }
                  
                 rs2.beforeFirst();
                 if(rs2.next() && !(c.createStatement().executeQuery("select * from postresult where result='"+cid+"' and pid="+pid).next())  )
                 {
                     
                c.createStatement().executeUpdate("insert into postresult values("+pid+",'"+cid+"')");
                 }
                rs2.close();
            }
            
             rs.close();
            
            
            Thread.currentThread().sleep(1000);
            c.close();
        } catch (Exception e) {
            System.err.println(e);
        }
        
        }
    }
    public static void main(String[] args) {
        new CalculateVoteThread();
    }
    
}
