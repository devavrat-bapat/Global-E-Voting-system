/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import me.evote.hencrypt.MyDBConnection;

/**
 *
 * @author Devavrat
 */
public class EditCProfile extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           String un = request.getParameter("un");
        String desg=request.getParameter("desg"),
                
                email = request.getParameter("email"),
                 phno = request.getParameter("phno"),
                address1 = request.getParameter("add1"),
                address2 = request.getParameter("add2"),
                 orgn = request.getParameter("orgname");
        String proof = request.getParameter("proof"),
                nov=request.getParameter("nov");
                String pass = request.getParameter("password");
         
        
         
        Connection conn = null; // connection to the database
        String message = null;  // message will be sent back to client
         
        try {
            // connects to the database
             
            conn =MyDBConnection.getCon();
 
            // constructs SQL statement
            String sql = "update clientdetails set name=?,password=?,designation=?,phno=?,email=?,address1=?,address2=?,orgname=?,autproof=?,novoters=? where username=?";
            
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, un);
            statement.setString(2, pass);
            statement.setString(3, desg);
             statement.setString(4, phno);
            statement.setString(5, email);
            statement.setString(6, address1);
            statement.setString(7,  address2);
            
            statement.setString(8,orgn);
             statement.setString(9,  proof);
            statement.setString(10,nov);
            statement.setString(11,request.getSession().getAttribute("un").toString());
            //statement.setString(11, pass);
            // sends the statement to the database server
            int row = statement.executeUpdate();
            if (row > 0) {
                message = "File uploaded and saved into database";
                response.sendRedirect("EVClient.jsp");
            }
        } catch (SQLException ex) {
            message = "ERROR: " + ex.getMessage();
            ex.printStackTrace();
            
        } finally {
            
            
        } 
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
