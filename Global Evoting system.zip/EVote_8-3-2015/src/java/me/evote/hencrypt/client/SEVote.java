/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.client;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import me.evote.hencrypt.MyDBConnection;

/**
 *
 * @author Devavrat
 */
public class SEVote extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
              String post = request.getParameter("cpost");
              String id = request.getParameter("vdid");
        String sdate=request.getParameter("sdate"),stime=request.getParameter("stime"),rsdate=request.getParameter("rsdate"),rstime=request.getParameter("rstime"),etime=request.getParameter("etime");
          Connection conn = null; // connection to the database
        String message = null;  // message will be sent back to client
         
        try {
            // connects to the database
             
            conn =MyDBConnection.getCon();
 ResultSet rs123=conn.createStatement().executeQuery("select * from cpost where post='"+post+"' and TIMESTAMPDIFF(Day,ldate, '"+sdate+"')<=0 ");
            System.out.println("select * from cpost where post='"+post+"' and TIMESTAMPDIFF(Day,ldate, '"+sdate+"')<=0 ;");
            if(rs123.next())
            {
                
                MyDBConnection.msg="post last date and voting satrt date is same";
               // out.println("<script  type= 'text/javascript'>alert('post last date and voting satrt date is same');</script>");
                 response.sendRedirect("EditVDtls.jsp?vdid="+id);
            
            }
            else{
            // constructs SQL statement
            String sql = "update votedtls set post=?,sdate=?,stime=?,etime=?,rsdate=?,rstime=?  where vdid=?";
            
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, post);
              statement.setString(2, sdate);
            statement.setString(7, id);
            statement.setString(4, etime);
             statement.setString(3, stime);
               statement.setString(5, rsdate);
             statement.setString(6, rstime);
            // sends the statement to the database server
            int row = statement.executeUpdate();
            if (row > 0) {
                message = "File uploaded and saved into database";
                response.sendRedirect("CSVoting.jsp");
            }
            }
        } catch (SQLException ex) {
            message = "ERROR: " + ex.getMessage();
            ex.printStackTrace();
            
        }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
