/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.client;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import me.evote.hencrypt.MyDBConnection;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.jdbc.JDBCPieDataset;
 

/**
 *
 * @author Devavrat
 */
public class PieChartServlet extends HttpServlet {
private static final long serialVersionUID = 1L;
        private Connection dbConnection = null;
   
        public PieChartServlet() {
                dbConnection = MyDBConnection.getCon();
        }

        public void doGet(HttpServletRequest request, HttpServletResponse response)
                        throws ServletException, IOException {
                try {
                    MyDBConnection.getCon().createStatement().executeUpdate("insert into creategraph SELECT canname,(noofvotes/noofvoters)*100 FROM votepercentage where cid='"+request.getSession().getAttribute("un")+"' and post='"+request.getParameter("cpost")+"'");
                    JDBCPieDataset dataSet = new JDBCPieDataset(MyDBConnection.getCon());
                    
                    try {
                        dataSet.executeQuery("select * from creategraph");
                        JFreeChart chart = ChartFactory.createPieChart(
                                "E Vote- "+request.getParameter("cpost"), // Title
                                dataSet,                    // Data
                                true,                       // Display the legend
                                true,                       // Display tool tips
                                false                       // No URLs
                        );
                        
                        if (chart != null) {
                            chart.setBorderVisible(true);
                            int width = 600;
                            int height = 400;
                            response.setContentType("image/jpeg");
                            OutputStream out = response.getOutputStream();
                                MyDBConnection.getCon().createStatement().executeUpdate("delete from creategraph");
                            ChartUtilities.writeChartAsJPEG(out, chart, width, height);
                        }
                    }
                    catch (SQLException e) {
                        System.err.println(e.getMessage());
                    }
                }
                catch (Exception ex) {
                        Logger.getLogger(PieChartServlet.class.getName()).log(Level.SEVERE, null, ex);
                }
        }

}
