/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.client;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import me.evote.hencrypt.MyDBConnection;

/**
 *
 * @author Devavrat
 */
public class AddVoter extends HttpServlet {
private String host;
    private String port;
    private String user;
    private String pass;
 
    public void init() {
        // reads SMTP server setting from web.xml file
        ServletContext context = getServletContext();
        host = context.getInitParameter("host");
        port = context.getInitParameter("port");
        user = context.getInitParameter("user");
        pass = context.getInitParameter("pass");
    }
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            /* TODO output your page here. You may use following sample code. */
               String regno = request.getParameter("regno");
        String desg=request.getParameter("desg"),
                imei = request.getParameter("imei"),
                  doj = request.getParameter("doj"),
                gender=request.getParameter("gender"),
                email = request.getParameter("email"),
                 phno = request.getParameter("phno"),
                address = request.getParameter("address"),
                 dob = request.getParameter("dob"), 
                un = request.getParameter("un"),
                 pass = request.getParameter("pass");
        String name = request.getParameter("sname");
        
         
        
         
        Connection conn = null; // connection to the database
       //  String message = null;  // message will be sent back to client
         
        try {
            // connects to the database
             
            conn =MyDBConnection.getCon();
 
            // constructs SQL statement
            String sql = "INSERT INTO voterdetails (empcode,name,address,desg,imei,dob,gender,cid,email,phno,doj,uname,password) values (?,?,?, ?, ?,?,?,?,?,?,?,?,?)";
            
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, regno);
            statement.setString(2, name);
             statement.setString(3, address);
            statement.setString(4, desg);
            statement.setString(5, imei);
            statement.setString(6,  dob);
            statement.setString(7,gender);
            statement.setString(8,  request.getSession().getAttribute("un").toString());
           
             statement.setString(9,  email);
            statement.setString(10,phno);
            statement.setString(11,doj);
             statement.setString(12,un);
            statement.setString(13,pass);
 
            // sends the statement to the database server
            int row = statement.executeUpdate();
            
            //email vooter his/her uname/pass--------------- uncomment the data
            
 
            String result;
   // Recipient's email ID needs to be mentioned.
   String to = email;

   // Sender's email ID needs to be mentioned
   String from = "abcd@xyz.com";   // insert your email address here

   // Assuming you are sending email from localhost
   String host = "localhost";

   // Get system properties object
  Properties props = new Properties();
         props.put("mail.smtp.user","ddagevote"); 
props.put("mail.smtp.host", "smtp.gmail.com"); 
props.put("mail.smtp.port", "25"); 
props.put("mail.debug", "true"); 
props.put("mail.smtp.auth", "true"); 
props.put("mail.smtp.starttls.enable","true"); 
props.put("mail.smtp.EnableSSL.enable","true");

props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");   
props.setProperty("mail.smtp.socketFactory.fallback", "false");   
props.setProperty("mail.smtp.port", "465");   
props.setProperty("mail.smtp.socketFactory.port", "465"); 
   // Get the default Session object.
   Session mailSession = Session.getInstance(props, new javax.mail.Authenticator() {
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication("abcd", "xyz");    // insert your email address @ abcd and password @ xyz
                }
            });
   
      // Create a default MimeMessage object.
      MimeMessage message = new MimeMessage(mailSession);
      // Set From: header field of the header.
      message.setFrom(new InternetAddress(from));
      // Set To: header field of the header.
      message.addRecipient(Message.RecipientType.TO,
                               new InternetAddress(to));
      // Set Subject: header field
      message.setSubject("Account Details");
      // Now set the actual message
      message.setText("User ID "+un+" and Password "+pass);
      // Send message
      Transport.send(message);
      result = "Sent message successfully....";
  
            
            if (row > 0) {
                  response.sendRedirect("VotersDetails.jsp");
            }
        } catch (SQLException ex) {
//            message = "ERROR: " + ex.getMessage();
            ex.printStackTrace();
            
        }   catch (MessagingException ex) {
                Logger.getLogger(AddVoter.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
            
            
        } 
        } finally {
//            out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
