/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.client;

import java.io.IOException;
import java.sql.*;
import java.io.PrintWriter;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import me.evote.hencrypt.MyDBConnection;
import me.evote.hencrypt.voter.Encrypt;

/**
 *
 * @author Devavrat
 */
public class GiveVote extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String jspName = request.getSession().getAttribute("jpname").toString();
            /* TODO output your page here. You may use following sample code. */
           String j=request.getParameter("sub");
           if(j.equals("Change"))
           {
             //  String jspName = request.getSession().getAttribute("jpname").toString();
RequestDispatcher rd = request.getRequestDispatcher(jspName);

rd.forward(request, response);
           }
           else
           {
               String q="select * from fvotedtls where  client='"+request.getSession().getAttribute("cid").toString()+"' and voterid='"+request.getSession().getAttribute("un").toString()+"' and post='"+request.getParameter("post")+"'";
               System.out.println(q);
                Statement s=MyDBConnection.getCon().createStatement();
            ResultSet rs=s.executeQuery(q);
             if(rs.next())
            {
                
RequestDispatcher rd = request.getRequestDispatcher(jspName);
request.getSession().setAttribute("msg","You already voted for this post");
 rd.forward(request, response);
            }
             else
             {
                 //encrypt vote to homomorphic encryption
                 
                 String hme=Encrypt.Encrypt("1");
                 
                 
                Statement s1=MyDBConnection.getCon().createStatement();                
                  String q1="insert into fvotedtls(canid,client,voterid,post,vote,vdtime) values('"+request.getParameter("un")+"','"+request.getSession().getAttribute("cid").toString()+"','"+request.getSession().getAttribute("un").toString()+"','"+request.getParameter("post")+"','"+hme+"','"+new java.util.Date()+"')";
               System.out.println(q1);
 
                if(s1.executeUpdate(q1)>0)
                {
                    RequestDispatcher rd = request.getRequestDispatcher(jspName);
request.getSession().setAttribute("msg","Voting Done ");
 rd.forward(request, response);
                }
                else
                {
                      
RequestDispatcher rd = request.getRequestDispatcher(jspName);
request.getSession().setAttribute("msg","Problem in Voting");
 rd.forward(request, response);
                }
             }
           }
           
        
        } catch (SQLException ex) {
            Logger.getLogger(GiveVote.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
