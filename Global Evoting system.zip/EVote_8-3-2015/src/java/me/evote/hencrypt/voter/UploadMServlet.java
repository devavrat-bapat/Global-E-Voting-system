/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.voter;

import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Devavrat
 */
 import java.io.File;
import com.oreilly.servlet.multipart.MultipartParser;
import com.oreilly.servlet.multipart.Part;
import com.oreilly.servlet.multipart.FilePart;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import me.evote.hencrypt.MyDBConnection;

public class UploadMServlet extends HttpServlet {

    private String fileSavePath;
    private static final String UPLOAD_DIRECTORY = "Upload";

    public void init() {
        fileSavePath = getServletContext().getRealPath("/") + File.separator + UPLOAD_DIRECTORY;/*save uploaded files to a 'Upload' directory in the web app*/
        if (!(new File(fileSavePath)).exists()) {
            (new File(fileSavePath)).mkdir();    // creates the directory if it does not exist        
        }
    }
    @Override
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
  doPost( request,  response);}
  
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, java.io.IOException {
//        String resp = "";
//        int i = 1;
//        resp += "<br>Here is information about uploaded files.<br>";
//        String fn[]=new String[6];
//        int con=0;
//        try {
//            MultipartParser parser = new MultipartParser(request, 1024 * 1024 * 1024);  /* file limit size of 1GB*/
//            Part _part;
//            while ((_part = parser.readNextPart()) != null) {
//                if (_part.isFile()) {
//                    FilePart fPart = (FilePart) _part;  // get some info about the file
//                    String name = fPart.getFileName();
//                    System.out.println(name);
//                    fn[con]=name;
//                    con++;
//                    if (name != null) {
//                        long fileSize = fPart.writeTo(new File(fileSavePath));
//                        resp += i++ + ". " + fPart.getFilePath() + "[" + fileSize / 1024 + " KB]<br>";
//                    } else {
//                        resp = "<br>The user did not upload a file for this part.";
//                    }
//                }
//            }// end while 
//            
//            
//            
//            
//        } catch (Exception ioe) {
//            resp = ioe.getMessage();
//            System.out.println(resp);
//        }
        System.out.println("File uploaded");
        
         try   {
            /*
            
            TODO output your page here. You may use following sample code. */
            Connection c=MyDBConnection.getCon();
           Statement s=c.createStatement();
           System.out.println("+ldate");
              String d111=(Calendar.getInstance().getTime().getYear()+1900)+"-"+(Calendar.getInstance().getTime().getMonth()+1)+"-"+(Calendar.getInstance().getTime().getDate());
                //  System.out.println("select * from cpost where ldate > '"+d111+"' and  pid="+request.getSession().getAttribute("PID").toString()+" and cid='"+request.getSession().getAttribute("cid")+"'");
      //     String d111=(Calendar.getInstance().getTime().getYear()+1900)+"-"+(Calendar.getInstance().getTime().getMonth()+1)+"-"+(Calendar.getInstance().getTime().getDay()+1);
         //   ResultSet rs=s.executeQuery("select * from cpost where ldate >= '"+d111+"' and  pid="+request.getSession().getAttribute("PID").toString()+" and cid='"+request.getSession().getAttribute("cid")+"'");
                  int age=0,exp=0;
                
                  
                  ResultSet rs=s.executeQuery("select * from cpost where  TIMESTAMPDIFF(Day,ldate,CURDATE())<=0 and  pid="+request.getParameter("id")+" and cid='"+request.getSession().getAttribute("cid")+"'");
                  System.out.println("select * from cpost where TIMESTAMPDIFF(Day,ldate,CURDATE())<=0 and  pid="+request.getParameter("id")+" and cid='"+request.getSession().getAttribute("cid")+"'");
int              i=0;
            String id="";
     
            if(rs.next())
            {
                
                int agee=rs.getInt("agel");
                int expp=rs.getInt("expl");
                  ResultSet rs123=c.createStatement().executeQuery("SELECT TIMESTAMPDIFF(YEAR,dob,CURDATE()) AS age\n" +
", name FROM voterdetails where TIMESTAMPDIFF(YEAR,dob,CURDATE())>="+agee+" and TIMESTAMPDIFF(YEAR,doj,CURDATE()) >="+expp+" and uname='"+request.getSession().getAttribute("un").toString()+"'");
                  if(!rs123.next())
                  {
                       request.getSession().setAttribute("msg","Your Age Limit or Experiance Limit not matched ");
                         response.sendRedirect("VPosts.jsp");
                  }else{
             System.out.println("next");
       String p=rs.getString("post");
        Statement s2=c.createStatement();
       ResultSet rs1=s2.executeQuery("select * from candidatedetails where uname='"+request.getSession().getAttribute("un")+"' and forpost='"+p+"'");
       if(rs1.next())
       {
       
       request.getSession().setAttribute("msg","You cannot apply for the post you already applied ");
       response.sendRedirect("VPosts.jsp");
       }
       else{
       
        Statement s1=c.createStatement();
        int ii=s1.executeUpdate("insert into candidatedetails(name,address,phno,email,cid,empcode,desg,imei,dob,doj,gender,allowed,forpost,uname)"
                + " select name,address,phno,email,cid,empcode,desg,imei,dob,doj,gender,'Pending','"+p+"',uname from voterdetails where uname='"+request.getSession().getAttribute("un")+"'");
           request.getSession().setAttribute("msg","You apply for the postsuccessfully");
       response.sendRedirect("VPosts.jsp");
       }
                  } }
            else
            {
//                  out.println("<script type=\"text/javascript\">");
//       out.println("alert('You cannot apply for the post last date is over 1');");
//       out.println("</script>");
                 request.getSession().setAttribute("msg","You cannot apply for the post last date is over");
       
       response.sendRedirect("VPosts.jsp");
            }
        } catch (SQLException ex) {
            System.out.println(ex);
          //  Logger.getLogger(UploadMServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
}