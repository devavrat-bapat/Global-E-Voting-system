/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.voter;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import me.evote.hencrypt.MyDBConnection;

/**
 *
 * @author Devavrat
 */
@MultipartConfig(fileSizeThreshold=1024*1024*2, // 2MB
                 maxFileSize=1024*1024*10,      // 10MB
                 maxRequestSize=1024*1024*50)   // 50MB
public class UploadAServlet extends HttpServlet {

     /**
     * Name of the directory where uploaded files will be saved, relative to
     * the web application directory.
     */
    private static final String SAVE_DIR = "dummy";
     
    /**
     * handles file upload
     */
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
        // gets absolute path of the web application
        String appPath = request.getServletContext().getRealPath("");
        // constructs path of the directory to save uploaded file
        String savePath = appPath + File.separator + SAVE_DIR;
       //  savePath="D:\\dummy";
        // creates the save directory if it does not exists
        System.out.println(savePath);
        File fileSaveDir = new File(savePath);
        if (!fileSaveDir.exists()) {
            fileSaveDir.mkdir();
        }
         String f="";
        for (Part part : request.getParts()) {
            String fileName = extractFileName(part);
            f=fileName;
            
            part.write(savePath + File.separator + fileName);
        }
 
         try {
            // connects to the database
             
             Connection conn =MyDBConnection.getCon();
 
            // constructs SQL statement
            String sql = "INSERT INTO apromotions (filename,udate,uname,cid,audioname) values (?, ?, ?,?,?)";
            
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, f);
             statement.setString(5, f.substring(0,f.length()-5));
              statement.setString(2, new Date().toString());
            statement.setString(4, request.getSession().getAttribute("cid").toString());
            statement.setString(3, request.getSession().getAttribute("un").toString());
            
            // sends the statement to the database server
            int row = statement.executeUpdate();
            if (row > 0) {
               
                  request.setAttribute("message", "Upload has been done successfully!");
        getServletContext().getRequestDispatcher("/AddCAudioPromotions.jsp").forward(
                request, response);
            }
            else
                getServletContext().getRequestDispatcher("/AddCAudioPromotions.jsp").forward(
                request, response);
        } catch (SQLException ex) {
             System.out.println(ex);
            ex.printStackTrace();
            
        }
        
        
      
    }
 
    /**
     * Extracts file name from HTTP header content-disposition
     */
    private String extractFileName(Part part) {
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length()-1);
            }
        }
        return "";
    }
}
