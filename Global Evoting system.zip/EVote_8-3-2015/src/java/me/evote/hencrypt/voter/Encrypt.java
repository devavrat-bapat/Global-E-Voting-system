/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package me.evote.hencrypt.voter;

import java.util.Random;

/**
 *
 * @author Devavrat
 */
public class Encrypt  {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    public static String Encrypt(String val)
          {
        
         String pl= val;
         double m=0;
         int flag=1;
        try
        {
            m= Integer.parseInt(pl);
        }
        catch(Exception eq)
        {
            flag=0;
        //    out.println("Please enter number");
        }
/// HOMOMORPHIC ENCRYPTION
        if (flag==1)
        {
        Prime_Number_Generator pn = new Prime_Number_Generator();
        Random rand = new Random(); 					// generate a random number
	        double p,q,r,n,c;
                p= rand.nextInt(1000000);
	
	        while (!pn.isPrime(p)) 
		{          
	            p = rand.nextInt(1000000) + 1;
        	}
                
                q= rand.nextInt(1000000);
	
	        while (!pn.isPrime(q)) 
		{          
	            q = rand.nextInt(1000000) + 1;
        	}
                
                n=p*q;
                
//                out.printf("Prime Random Number: P: %.0f\n<br>", p);
//                out.printf("Prime Random Number: Q: %.0f\n<br>", q);
//                out.printf("Multiplication N: %.0f\n<br>", n);
//                
                r = rand.nextInt(1000000);
              //  out.printf("Random number: R: %.0f\n<br>", r);
                c=(m+r*p)%n;
              //  out.printf("Ciphertext: C: %.0f\n<br>", c);
                
                
// DECRYPTION OF THE CIPHERTEXT
                m=c%p;
            //    out.printf("Plaintext: M: %.0f\n<br>", m);
                return c+":"+p;
        } 
         return "";
    }
    public static String Decrypt(String val)
          {
        
         String pl= val;
         double m=0;
         int flag=1;
               String d[]=val.split(":");
       
        try
        {
           m= Integer.parseInt(d[0]);
        }
        catch(Exception eq)
        {
            flag=0;
        //    out.println("Please enter number");
        }
/// HOMOMORPHIC ENCRYPTION
        if (flag==1)
        {
        Prime_Number_Generator pn = new Prime_Number_Generator();
        Random rand = new Random(); 					// generate a random number
	        double p,q,r,n,c;
        p=Double.parseDouble(d[1]);
         c=Double.parseDouble(d[0]);
        
// DECRYPTION OF THE CIPHERTEXT
                m=c%p;
            //    out.printf("Plaintext: M: %.0f\n<br>", m);
                return c+":"+p;
        } 
         return "";
    }
}

